package com.mycompany.bai4.ui;

import com.mycompany.bai4.util.ChatColor;
import com.mycompany.bai4.server.ChatServer;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;



public class LoginDialog extends JDialog {

    
    //  Result                                                              
    public static class Result {
        public final String host;
        public final int    port;
        public final String username;
        public final String password;

        Result(String host, int port, String username, String password) {
            this.host     = host;
            this.port     = port;
            this.username = username;
            this.password = password;
        }
    }

    
    //  Fields                                                              
    private final JTextField     hostField;
    private final JTextField     userField;
    private final JPasswordField passField;

    private Result  result          = null;
    public boolean         openRegisterFlag = false;

    
    //  Constructor                                                        
    private LoginDialog(String initHost, String prefillUser) {
        super((Frame) null, "Đăng nhập", true);

        hostField = new JTextField(initHost, 20);
        userField = new JTextField(prefillUser, 20);
        passField = new JPasswordField(20);

        buildUI();
        pack();
        setResizable(false);
        setLocationRelativeTo(null);
    }

    
    //  UI                                                                  
    private void buildUI() {
        JPanel root = new JPanel(new BorderLayout(0, 14));
        root.setBorder(new EmptyBorder(20, 24, 16, 24));

        // --- Form ---
        JPanel form = buildGrid(
                new String[]{"Tên đăng nhập:", "Mật khẩu:", "Địa chỉ IP:"},
                new JComponent[]{userField, passField, hostField});

        // --- Buttons ---
        JButton btnLogin    = new JButton("Đăng nhập");
        JButton btnCancel   = new JButton("Hủy");
        JButton btnRegister = new JButton("Chưa có tài khoản? Đăng ký");
        btnRegister.setFont(ChatColor.FONT_SMALL);
        btnRegister.setBorderPainted(false);
        btnRegister.setContentAreaFilled(false);
        btnRegister.setForeground(ChatColor.ACCENT);
        btnRegister.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        btnRow.add(btnRegister);
        btnRow.add(btnCancel);
        btnRow.add(btnLogin);

        root.add(form,   BorderLayout.CENTER);
        root.add(btnRow, BorderLayout.SOUTH);
        setContentPane(root);

        // Enter để chuyển focus / submit
        userField.addActionListener(e -> passField.requestFocus());
        passField.addActionListener(e -> hostField.requestFocus());
        hostField.addActionListener(e -> onLogin());

        btnLogin.addActionListener(e -> onLogin());
        btnCancel.addActionListener(e -> dispose());
        btnRegister.addActionListener(e -> {
            openRegisterFlag = true;
            dispose();
        });
    }

    private void onLogin() {
        String host = hostField.getText().trim();
        String user = userField.getText().trim();
        String pwd  = new String(passField.getPassword());

        if (host.isEmpty()) { showError("Vui lòng nhập địa chỉ IP server."); return; }
        if (user.isEmpty()) { showError("Vui lòng nhập tên đăng nhập.");     return; }
        if (pwd.isEmpty())  { showError("Vui lòng nhập mật khẩu.");          return; }

        result = new Result(host, ChatServer.PORT, user, pwd);
        dispose();
    }

    private void showError(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Lỗi", JOptionPane.ERROR_MESSAGE);
    }

    
    //  Static factory                                                     
    public static LoginDialog showAndGet(String host, int port, String prefillUser) {
        LoginDialog dlg = new LoginDialog(host, prefillUser);
        dlg.setVisible(true);
        return dlg;
    }

    public Result getResult() { return result; }

    //  Helper                                                              
    private static JPanel buildGrid(String[] labels, JComponent[] fields) {
        JPanel p = new JPanel(new GridBagLayout());
        p.setBorder(new EmptyBorder(4, 0, 4, 0));
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(5, 4, 5, 4);
        g.anchor = GridBagConstraints.WEST;
        for (int i = 0; i < labels.length; i++) {
            g.gridx = 0; g.gridy = i; g.weightx = 0; g.fill = GridBagConstraints.NONE;
            p.add(new JLabel(labels[i]), g);
            g.gridx = 1; g.weightx = 1; g.fill = GridBagConstraints.HORIZONTAL;
            p.add(fields[i], g);
        }
        return p;
    }
}
