package com.mycompany.bai4.ui;

import com.mycompany.bai4.util.ChatColor;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;


public class RegisterDialog extends JDialog {

   
    //  Result                                                             
    public static class Result {
        public final String host;
        public final int    port;
        public final String username;
        public final String password;
        public final String displayName;

        Result(String host, int port, String username, String password, String displayName) {
            this.host        = host;
            this.port        = port;
            this.username    = username;
            this.password    = password;
            this.displayName = displayName;
        }
    }

   
    //  Fields                                                              
    private final JTextField     displayNameField;
    private final JTextField     userField;
    private final JPasswordField passField;
    private final JPasswordField pass2Field;

    private final String host;
    private final int    port;

    private Result  result        = null;
    public boolean         openLoginFlag = false;

    
    //  Constructor                                                         
    private RegisterDialog(String host, int port) {
        super((Frame) null, "Đăng ký tài khoản", true);

        this.host = host;
        this.port = port;

        displayNameField = new JTextField(20);
        userField        = new JTextField(20);
        passField        = new JPasswordField(20);
        pass2Field       = new JPasswordField(20);

        buildUI();
        pack();
        setResizable(false);
        setLocationRelativeTo(null);
    }

    
    //  UI                                                                  
    private void buildUI() {
        JPanel root = new JPanel(new BorderLayout(0, 14));
        root.setBorder(new EmptyBorder(20, 24, 16, 24));

        // Form 
        JPanel form = buildGrid(
                new String[]{"Tên người dùng:", "Tên đăng nhập:", "Mật khẩu:", "Xác nhận mật khẩu:"},
                new JComponent[]{displayNameField, userField, passField, pass2Field});

        //Buttons 
        JButton btnRegister = new JButton("Đăng ký");
        JButton btnCancel   = new JButton("Hủy");
        JButton btnLogin    = new JButton("Đã có tài khoản? Đăng nhập");
        btnLogin.setFont(ChatColor.FONT_SMALL);
        btnLogin.setBorderPainted(false);
        btnLogin.setContentAreaFilled(false);
        btnLogin.setForeground(ChatColor.ACCENT);
        btnLogin.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        btnRow.add(btnLogin);
        btnRow.add(btnCancel);
        btnRow.add(btnRegister);

        root.add(form,   BorderLayout.CENTER);
        root.add(btnRow, BorderLayout.SOUTH);
        setContentPane(root);

        // Enter để chuyển focus / submit
        displayNameField.addActionListener(e -> userField.requestFocus());
        userField.addActionListener(e -> passField.requestFocus());
        passField.addActionListener(e -> pass2Field.requestFocus());
        pass2Field.addActionListener(e -> onRegister());

        btnRegister.addActionListener(e -> onRegister());
        btnCancel.addActionListener(e -> dispose());
        btnLogin.addActionListener(e -> {
            openLoginFlag = true;
            dispose();
        });
    }

    private void onRegister() {
        String displayName = displayNameField.getText().trim();
        String user        = userField.getText().trim();
        String pwd         = new String(passField.getPassword());
        String pwd2        = new String(pass2Field.getPassword());

        if (displayName.isEmpty()) { showError("Vui lòng nhập tên người dùng.");  return; }
        if (user.isEmpty())        { showError("Vui lòng nhập tên đăng nhập.");   return; }
        if (pwd.isEmpty())         { showError("Vui lòng nhập mật khẩu.");        return; }
        if (!pwd.equals(pwd2)) {
            showError("Mật khẩu xác nhận không khớp.");
            pass2Field.setText("");
            pass2Field.requestFocus();
            return;
        }

        result = new Result(host, port, user, pwd, displayName);
        dispose();
    }

    private void showError(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Lỗi", JOptionPane.ERROR_MESSAGE);
    }

    
    //  Static factory                                                     
    
    public static RegisterDialog showAndGet(String host, int port) {
        RegisterDialog dlg = new RegisterDialog(host, port);
        dlg.setVisible(true);
        return dlg;
    }

    public Result getResult() { return result; }

    
    //  Helper                                                             
    private static JPanel buildGrid(String[] labels, JComponent[] fields) {
        JPanel p = new JPanel(new GridBagLayout());
        p.setBorder(new EmptyBorder(4, 0, 4, 0));
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(5, 4, 5, 4);
        g.anchor = GridBagConstraints.WEST;
        for (int i = 0; i < labels.length; i++) {
            g.gridx = 0; g.gridy = i; g.weightx = 0; g.fill = GridBagConstraints.NONE;
            p.add(new JLabel(labels[i]), g);
            g.gridx = 1; g.weightx = 1; g.fill = GridBagConstraints.HORIZONTAL;
            p.add(fields[i], g);
        }
        return p;
    }
}
